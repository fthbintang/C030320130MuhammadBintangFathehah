<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct()
	    {
	        parent::__construct();
	        $this->load->model('m_admin');
			$this->login_kah();	//Memastikan hanya yang sudah login dapat akses fungsi ini
	    }


	public function login_kah()
	{
		if ( $this->session->has_userdata('username') && $this->session->userdata('id_level')==1 )
			return TRUE; 
		else
		  	redirect(base_url('logout'));    
	}


	public function index()
	{
		$data['judul']	='Politeknik Negeri Banjarmasin';
		$data['page']	='home';
		// $data['jml_santri']	=$this->m_umum->jumlah_record_tabel('santri');
		// $data['jml_guru']	=$this->m_umum->jumlah_record_tabel('guru');
		$this->tampil($data);
	}

//============================== SANTRI ==============================
	public function mahasiswa()
	{
		$data['judul']='Daftar Mahasiswa';
		$data['page']='mahasiswa';
		$data['mahasiswa']=$this->m_admin->dt_mahasiswa();
		$this->tampil($data);
	}
	
	public function santri_detil($id)
	{
		$data['judul']='Detil Data Santri TPA Aisyiah';
		$data['page']='santri_detil';
		$data['d']=$this->m_admin->dt_santri_detil($id);
		$this->tampil($data);
	}

	public function mahasiswa_tambah()
	{
		$data['judul'] = 'Tambah Data Mahasiswa';
		$data['page'] = 'mahasiswa_tambah';

		$this->form_validation->set_rules(
			'nim',
			'NIM',
			'required|max_length[10]',
			array('required' => '%s harus diisi.')
		);
		$this->form_validation->set_rules(
			'nama_mhs',
			'Nama Mahasiswa', 
			'required',
			array('required' => '%s harus diisi'));
		$this->form_validation->set_rules(
			'tanggal_lahir',
			'Tanggal Lahir', 
			'required',
			array('required' => '%s harus diisi'));
		$this->form_validation->set_rules(
			'alamat',
			'Alamat', 
			'required',
			array('required' => '%s harus diisi'));
		

		if ($this->form_validation->run() === FALSE) {
			$this->tampil($data);
		} else {
			$this->m_admin->dt_mahasiswa_tambah();
			$this->session->set_flashdata('pesan_tambah');
			redirect(base_url('admin/mahasiswa'));
		}
	}
	
	public function mahasiswa_edit($id = FALSE)
	{
		$data['judul'] = 'Edit Data Mahasiswa';
		$data['page'] = 'mahasiswa_edit';

		$this->form_validation->set_rules(
			'nim',
			'NIM',
			'required|max_length[10]',
			array('required' => '%s harus diisi.')
		);
		$this->form_validation->set_rules(
			'nama_mhs',
			'Nama Mahasiswa', 
			'required',
			array('required' => '%s harus diisi'));
		$this->form_validation->set_rules(
			'tanggal_lahir',
			'Tanggal Lahir', 
			'required',
			array('required' => '%s harus diisi'));
		$this->form_validation->set_rules(
			'alamat',
			'Alamat', 
			'required',
			array('required' => '%s harus diisi'));
		

		$data['d'] = $this->m_umum->cari_data('mahasiswa_muhammadbintangfathehah', 'nim', $id);

		if ($this->form_validation->run() === FALSE) {
			$this->tampil($data);
		} else {
			$this->m_admin->dt_mahasiswa_edit($id);
			redirect(base_url('admin/mahasiswa'));
		}
	}

	public function mahasiswa_hapus($id)
	{
		$this->m_umum->hapus_data('mahasiswa_muhammadbintangfathehah', 'nim', $id);
		redirect(base_url('admin/mahasiswa'));
	}


//============================== UKM ==============================
	public function ukm()
	{
		$data['judul']='Daftar UKM';
		$data['page']='ukm';
		$data['ukm']=$this->m_admin->dt_ukm();
		$this->tampil($data);
	}

	public function ukm_tambah()
	{
		$data['judul'] = 'Tambah Data UKM';
		$data['page'] = 'ukm_tambah';

		$this->form_validation->set_rules(
			'nama_ukm',
			'Nama UKM',
			'required',
			array('required' => '%s harus diisi.')
		);
		$this->form_validation->set_rules(
			'deskripsi',
			'Deskripsi', 
			'required',
			array('required' => '%s harus diisi'));

		if ($this->form_validation->run() === FALSE) {
			$this->tampil($data);
		} else {
			$this->m_admin->dt_ukm_tambah();
			$this->session->set_flashdata('pesan_tambah');
			redirect(base_url('admin/ukm'));
		}		
	}

	public function ukm_edit($id = FALSE)
	{
		$data['judul'] = 'EDIT data UKM';
		$data['page'] = 'ukm_edit';

		$this->form_validation->set_rules(
			'id_ukm',
			'ID UKM',
			'required',
			array('required' => '%s harus diisi.')
		);

		$this->form_validation->set_rules(
			'nama_ukm',
			'Nama UKM',
			'required',
			array('required' => '%s harus diisi.')
		);
		$this->form_validation->set_rules(
			'deskripsi',
			'Deskripsi',
			'required',
			array('required' => '%s harus diisi.')
		);

		$data['d'] = $this->m_umum->cari_data('ukm_muhammadbintangfathehah', 'id_ukm', $id);

		if ($this->form_validation->run() === FALSE) {
			$this->tampil($data);
		} else {
			$this->m_admin->dt_ukm_edit($id);
			redirect(base_url('admin/ukm'));
		}
	}

	public function ukm_hapus($id)
	{
		$this->m_umum->hapus_data('ukm_muhammadbintangfathehah','id_ukm',$id);
		redirect(base_url('admin/ukm'));
	}

//============================== PENDAFTARAN ANGGOTA ==============================
	public function daftar()
	{
	    $data['judul'] = 'Daftar Anggota UKM';
	    $data['page'] = 'daftar';
	    
	    // Mendapatkan pilihan UKM dari model
	    $data['ukm_options'] = $this->m_admin->get_ukm_options();

	    // Mengecek apakah ada permintaan pencarian berdasarkan UKM
	    $selected_ukm = $this->input->get('id_ukm');
	    $data['selected_ukm'] = $selected_ukm; // Tetapkan nilainya, bahkan jika kosong

	    if (!empty($selected_ukm)) {
	        $data['daftar'] = $this->m_admin->dt_daftar_by_ukm($selected_ukm);
	    } else {
	        $data['daftar'] = $this->m_admin->dt_daftar();
	    }

	    $this->tampil($data);
	}

	public function daftar_tambah()
	{
		$data['judul'] = 'Daftar UKM';
		$data['page'] = 'daftar_tambah';

		$this->form_validation->set_rules('nim', 'Pilih NIM', 'callback_dd_cek');

		$this->form_validation->set_rules('id_ukm', 'Pilih UKM', 'callback_dd_cek');

		$data['ddmahasiswa'] = $this->m_admin->dropdown_mahasiswa();
		$data['ddukm'] = $this->m_admin->dropdown_ukm();

		if ($this->form_validation->run() === FALSE) {
			$this->tampil($data);
		} else {
			$this->m_admin->dt_daftar_tambah();
			$this->session->set_flashdata('pesan_tambah');
			redirect(base_url('admin/daftar'));
		}		
	}

	public function daftar_edit($id = FALSE)
	{
		$data['judul'] = 'EDIT data UKM';
		$data['page'] = 'ukm_edit';

		$this->form_validation->set_rules(
			'id_ukm',
			'ID UKM',
			'required',
			array('required' => '%s harus diisi.')
		);

		$this->form_validation->set_rules(
			'nama_ukm',
			'Nama UKM',
			'required',
			array('required' => '%s harus diisi.')
		);
		$this->form_validation->set_rules(
			'deskripsi',
			'Deskripsi',
			'required',
			array('required' => '%s harus diisi.')
		);

		$data['d'] = $this->m_umum->cari_data('ukm_muhammadbintangfathehah', 'id_ukm', $id);

		if ($this->form_validation->run() === FALSE) {
			$this->tampil($data);
		} else {
			$this->m_admin->dt_ukm_edit($id);
			redirect(base_url('admin/ukm'));
		}
	}

	public function daftar_hapus($id)
	{
		$this->m_umum->hapus_data('daftar_muhammadbintangfathehah','id_daftar',$id);
		redirect(base_url('admin/daftar'));
	}

//============ Tools ===============
	function dd_cek($str)    //Untuk Validasi DropDown jika tidak dipilih
	{
	    if ($str == '-Pilih-') {
	      $this->form_validation->set_message('dd_cek', 'Harus dipilih');
	      return FALSE;
	    } else
	      return TRUE;
	}

	function tampil($data)
	{
		$this->load->view('admin/header',$data);
		$this->load->view('admin/isi');
		$this->load->view('admin/footer');
	}
}



