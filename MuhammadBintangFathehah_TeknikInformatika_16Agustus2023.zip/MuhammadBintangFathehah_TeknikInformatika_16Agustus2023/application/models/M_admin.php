<?php
class M_admin extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }
//=============================== SANTRI ===============================
    public function dt_mahasiswa()
    {
        $this->db->select('m.*');
        $this->db->from('mahasiswa_muhammadbintangfathehah m');
        $query = $this->db->get();
        return $query->result_array();        
    }

    public function dt_mahasiswa_tambah()
    {
        $data = array(
            'nim' => $this->input->post('nim'),
            'nama_mhs' => $this->input->post('nama_mhs'),
            'tanggal_lahir' => $this->input->post('tanggal_lahir'),
            'alamat' => $this->input->post('alamat')
        );
        return $this->db->insert('mahasiswa_muhammadbintangfathehah', $data);
    }

    public function dt_mahasiswa_edit($id)
    {
        $data = array(
            'nim' => $this->input->post('nim'),
            'nama_mhs' => $this->input->post('nama_mhs'),
            'tanggal_lahir' => $this->input->post('tanggal_lahir'),
            'alamat' => $this->input->post('alamat')
        );
        $this->db->where('nim', $id);
        return $this->db->update('mahasiswa_muhammadbintangfathehah', $data);
    }

    public function dropdown_mahasiswa()
    {
        $query = $this->db->get('mahasiswa_muhammadbintangfathehah');
        $result = $query->result();

        $mahasiswa_options = array();

        for ($i = 0; $i < count($result); $i++) {
            $nim = $result[$i]->nim;
            $nama_mhs = $result[$i]->nama_mhs;
            $mahasiswa_options[$nim] = $nim . ' - ' . $nama_mhs;
        }
        return $mahasiswa_options;
    }


//=============================== UKM===============================
    public function dt_ukm($id = FALSE)
    {
        $this->db->select('u.*');
        $this->db->from('ukm_muhammadbintangfathehah u');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function dt_ukm_tambah()
    {
        $data = array(
            'id_ukm' => $this->input->post('id_ukm'),
            'nama_ukm' => $this->input->post('nama_ukm'),
            'deskripsi' => $this->input->post('deskripsi'),
        );

        return $this->db->insert('ukm_muhammadbintangfathehah', $data);
    }  

    public function dt_ukm_edit($id)
    {
        $data = array(
            'id_ukm' => $this->input->post('id_ukm'),
            'nama_ukm' => $this->input->post('nama_ukm'),
            'deskripsi' => $this->input->post('deskripsi'),
        );
        $this->db->where('id_ukm', $id);
        return $this->db->update('ukm_muhammadbintangfathehah', $data);        
    }

    public function dropdown_ukm()
    {
        $query = $this->db->get('ukm_muhammadbintangfathehah');
        $result = $query->result();

        $id_ukm = array('-Pilih-');
        $nama_ukm = array('-Pilih-');

        for ($i = 0; $i < count($result); $i++) {
            array_push($id_ukm, $result[$i]->id_ukm);
            array_push($nama_ukm, $result[$i]->nama_ukm);
        }
        return array_combine($id_ukm, $nama_ukm);
    }

    //=============================== DAFTAR ===============================
    public function dt_daftar($id = FALSE)
    {
        $this->db->select('d.*, m.*, u.*');
        $this->db->from('daftar_muhammadbintangfathehah d');
        $this->db->join('mahasiswa_muhammadbintangfathehah m', 'm.nim = d.nim','left');
        $this->db->join('ukm_muhammadbintangfathehah u', 'u.id_ukm = d.id_ukm','left');
        $query = $this->db->get();
        return $query->result_array();
    }

    public function dt_daftar_tambah()
    {
        $data = array(
            'nim' => $this->input->post('nim'),
            'id_ukm' => $this->input->post('id_ukm')
        );

        return $this->db->insert('daftar_muhammadbintangfathehah', $data);
    }  

    public function dt_daftar_edit($id)
    {
        $data = array(
            'id_ukm' => $this->input->post('id_ukm'),
            'nama_ukm' => $this->input->post('nama_ukm'),
            'deskripsi' => $this->input->post('deskripsi'),
        );
        $this->db->where('id_ukm', $id);
        return $this->db->update('ukm_muhammadbintangfathehah', $data);        
    }

    public function get_ukm_options()
    {
        $this->db->select('id_ukm, nama_ukm');
        $query = $this->db->get('ukm_muhammadbintangfathehah');
        $result = $query->result_array();

        $options = array();
        foreach ($result as $row) {
            $options[$row['id_ukm']] = $row['nama_ukm'];
        }

        return $options;
    }

    public function dt_daftar_by_ukm($id_ukm)
    {
        $this->db->select('d.*, m.*, u.*');
        $this->db->from('daftar_muhammadbintangfathehah d');
        $this->db->join('mahasiswa_muhammadbintangfathehah m', 'm.nim = d.nim', 'left');
        $this->db->join('ukm_muhammadbintangfathehah u', 'u.id_ukm = d.id_ukm', 'left');
        $this->db->where('d.id_ukm', $id_ukm);

        $query = $this->db->get();
        return $query->result_array();
    }
 

}