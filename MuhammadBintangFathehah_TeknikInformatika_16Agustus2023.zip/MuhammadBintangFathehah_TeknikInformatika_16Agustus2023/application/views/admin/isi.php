<?php
//==================================== HOME ====================================
if ($page == 'home') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Selamat Datang Admin</h3>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>

        <div class="card-body">
          <h2>Ini Halaman Index</h2>
        </div>
      </div>

    </section>
  </div>
<?php
}

//==================================== MAHASISWA ====================================
else if ($page == 'mahasiswa') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <?php if ($this->session->flashdata('pesan_tambah')): ?>
        <script>alert("Data telah berhasil ditambah!")</script>
    <?php endif; ?>

    <section class="content">
      <div class="card">
        <div class="card-body">
          <a href=<?php echo base_url("admin/mahasiswa_tambah") ?> class="btn btn-primary" style="margin-bottom:15px">
            Tambah Mahasiswa</a>
          <table id="datatable_mahasiswa" class="table table-bordered">
            <thead>
              <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <?php
            foreach ($mahasiswa as $d) { ?>
              <tr>
                <td><?php echo $d['nim'] ?></td>
                <td><?php echo $d['nama_mhs'] ?></td>
                <td><?php echo $d['tanggal_lahir'] ?></td>
                <td><?php echo $d['alamat'] ?></td>
                <td>
                  <a href=<?php echo base_url("admin/mahasiswa_edit/") . $d['nim']; ?>> <i class="fas fa-pencil-alt"></i> </a>
                  <a href=<?php echo base_url("admin/mahasiswa_hapus/") . $d['nim']; ?> onclick="return confirm('Yakin menghapus Mahasiswa : <?php echo $d['nama_mhs']; ?> ?');" ;><i class="fas fa-trash-alt"></i></a>

                </td>
              </tr>
            <?php
            }
            ?>
          </table>

        </div>
    </section>
  </div>

<?php
}

//--------------------------------- Detil ---------------------------------
else if ($page == 'santri_detil') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-body">

          <dl class="row">
            <dt class="col-sm-2">Id Santri</dt>
            <dd class="col-sm-10"><?php echo $d['id_santri']; ?></dd>
            <dt class="col-sm-2">Nama Santri</dt>
            <dd class="col-sm-10"><?php echo $d['nama_santri']; ?></dd>
            <dt class="col-sm-2">Nama Alias</dt>
            <dd class="col-sm-10"><?php echo $d['nama_alias']; ?></dd>
            <dt class="col-sm-2">Nama Guru</dt>
            <dd class="col-sm-10"><?php echo $d['nama_guru']; ?></dd>
            <dt class="col-sm-2">Kelas</dt>
            <dd class="col-sm-10"><?php echo $d['nama_kelas']; ?></dd>
          </dl>

        </div>
      </div>
    </section>
  </div>
<?php

  //--------------------------------- Tambah ---------------------------------
} else if ($page == 'mahasiswa_tambah') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-body">

          <form method="POST" action="<?php echo base_url('admin/mahasiswa_tambah'); ?>" class="form-horizontal">

            <div class="card-body">

              <div class="form-group row">
                <label for="nim" class="col-sm-2 col-form-label">NIM</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nim" id="nim" value="<?php echo set_value('nim'); ?>" placeholder="Masukkan NIM">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nim')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="nama_mhs" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nama_mhs" id="nama_mhs" value="<?php echo set_value('nama_mhs'); ?>" placeholder="Masukkan Nama">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nama_mhs')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="tanggal_lahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="tanggal_lahir" id="tanggal_lahir" value="<?php echo set_value('tanggal_lahir'); ?>" placeholder="Masukkan Tanggal Lahir">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('tanggal_lahir')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="alamat" id="alamat" value="<?php echo set_value('alamat'); ?>" placeholder="Masukkan Alamat">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('alamat')); ?></span>
                </div>
              </div>

            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">Simpan</button>
              <button type="reset" class="btn btn-danger">Reset</button>
              <a href="<?php echo base_url('admin/mahasiswa'); ?>" class="btn btn-secondary">Kembali</a>
            </div>
          </form>


        </div>
    </section>
  </div>
<?php

  //--------------------------------- Edit ---------------------------------
} else if ($page == 'mahasiswa_edit') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-body">

          <form method="POST" action="<?php echo base_url('admin/mahasiswa_edit/' . $d['nim']); ?>" class="form-horizontal">

            <div class="card-body">

              <div class="form-group row">
                <label for="nim" class="col-sm-2 col-form-label">NIM</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nim" id="nim" value="<?php echo set_value('nim', $d['nim']); ?>" placeholder="Masukkan NIM" readonly>
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nama_santri')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="nama_mhs" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nama_mhs" id="nama_mhs" value="<?php echo set_value('nama_mhs', $d['nama_mhs']); ?>" placeholder="Masukkan Nama">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nama_mhs')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="tanggal_lahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="tanggal_lahir" id="tanggal_lahir" value="<?php echo set_value('tanggal_lahir', $d['tanggal_lahir']); ?>" placeholder="Masukkan Tanggal Lahir">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('tanggal_lahir')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="alamat" id="alamat" value="<?php echo set_value('alamat', $d['alamat']); ?>" placeholder="Masukkan Alamat">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('alamat')); ?></span>
                </div>
              </div>


            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">Simpan</button>
              <a href="<?php echo base_url('admin/mahasiswa'); ?>" class="btn btn-secondary">Kembali</a>
            </div>
          </form>


        </div>
    </section>
  </div>
<?php
}

//==================================== UKM ====================================
else if ($page == 'ukm') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-body">
          <a href=<?php echo base_url("admin/ukm_tambah") ?> class="btn btn-primary" style="margin-bottom:15px">Tambah UKM</a>
          <table class="table table-bordered" id="datatable_ukm">
            <thead>
              <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
              </tr>
            </thead>

            <?php
            foreach ($ukm as $d) { ?>
              <tr>
                <td><?php echo $d['id_ukm'] ?></td>
                <td><?php echo $d['nama_ukm'] ?></td>
                <td><?php echo $d['deskripsi'] ?></td>
                <td>
                  <a href=<?php echo base_url("admin/ukm_edit/") . $d['id_ukm']; ?>> <i class="fas fa-pencil-alt"></i> </a>
                  <a href=<?php echo base_url("admin/ukm_hapus/") . $d['id_ukm']; ?> onclick="return confirm('Yakin menghapus Mahasiswa : <?php echo $d['nama_ukm']; ?> ?');" ;><i class="fas fa-trash-alt"></i></a>

                </td>
              </tr>
            <?php
            }
            ?>
          </table>

        </div>
      </div>
    </section>
  </div>

<?php
}

//--------------------------------- TAMBAH ---------------------------------
else if ($page == 'ukm_tambah') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Isikan Data Dengan Benar</h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors(); ?>

          <form method="POST" action="<?php echo base_url('admin/ukm_tambah'); ?>" class="form-horizontal">

            <div class="card-body">

              <div class="form-group row">
                <label for="nama_ukm" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nama_ukm" id="nama_ukm" value="<?php echo set_value('nama_ukm'); ?>" placeholder="Masukkan Nama UKM">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nama_ukm')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="deskripsi" id="deskripsi" value="<?php echo set_value('deskripsi'); ?>" placeholder="Masukkan Deskripsi">
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('deskripsi')); ?></span>
                </div>
              </div>

            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">Simpan</button>
              <button type="reset" class="btn btn-danger">Reset</button>
              <a href="<?php echo base_url('admin/ukm'); ?>" class="btn btn-secondary">Kembali</a>
            </div>
          </form>

        </div>
      </div>
    </section>
  </div>

<?php
}

//--------------------------------- EDIT ---------------------------------
else if ($page == 'ukm_edit') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Isikan Data Dengan Benar</h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors(); ?>

          <form method="POST" action="<?php echo base_url('admin/ukm_edit/' . $d['id_ukm']); ?>" class="form-horizontal">

            <div class="card-body">

              <div class="form-group row">
                <label for="id_ukm" class="col-sm-2 col-form-label">ID</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="id_ukm" id="id_ukm" value="<?php echo set_value('id_ukm', $d['id_ukm']); ?>" placeholder="Masukkan ID" readonly>
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('id_ukm')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="nama_ukm" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nama_ukm" id="nama_ukm" value="<?php echo set_value('nama_ukm', $d['nama_ukm']); ?>" placeholder="Masukkan Nama UKM" >
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nama_ukm')); ?></span>
                </div>
              </div>
              <div class="form-group row">
                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="deskripsi" id="deskripsi" value="<?php echo set_value('deskripsi', $d['deskripsi']); ?>" placeholder="Masukkan Deskripsi" >
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('deskripsi')); ?></span>
                </div>
              </div>

            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">Simpan</button>
              <button type="reset" class="btn btn-danger">Reset</button>
              <a href="<?php echo base_url('admin/ukm'); ?>" class="btn btn-secondary">Kembali</a>
            </div>
          </form>

        </div>
      </div>
    </section>
  </div>

<?php
}

//==================================== DAFTAR ====================================
else if ($page == 'daftar') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-body">
          <a href=<?php echo base_url("admin/daftar_tambah") ?> class="btn btn-primary" style="margin-bottom:15px">Daftar Anggota Baru</a>
          <table class="table table-bordered" id="datatable_daftar">
            <thead>
              <tr>
                <th>NIM</th>
                <th>Nama Mahasiswa</th>
                <th>UKM</th>
                <th>Aksi</th>
              </tr>
            </thead>

            <?php
            foreach ($daftar as $d) { ?>
              <tr>
                <td><?php echo $d['nim'] ?></td>
                <td><?php echo $d['nama_mhs'] ?></td>
                <td><?php echo $d['nama_ukm'] ?></td>
                <td>
                  <!-- <a href=<?php echo base_url("admin/ukm_edit/") . $d['id_ukm']; ?>> <i class="fas fa-pencil-alt"></i> </a> -->
                  <a href=<?php echo base_url("admin/daftar_hapus/") . $d['id_daftar']; ?> onclick="return confirm('Yakin menghapus Mahasiswa : <?php echo $d['nama_mhs']; ?> ?');" ;>Keluarkan</a>

                </td>
              </tr>
            <?php
            }
            ?>
          </table>

          <!-- Dropdown untuk memilih UKM -->
          <div class="row mb-2">
            <div class="col-sm-6">
              <h3>Cari Anggota UKM</h3>
              <form method="get" action="<?php echo base_url('admin/daftar'); ?>">
                <div class="form-group">
                  <label for="id_ukm">Pilih UKM:</label>
                  <select name="id_ukm" class="form-control">
                    <option value="">-- Pilih UKM --</option>
                    <!-- Loop untuk menampilkan pilihan UKM dari model atau database -->
                    <?php foreach ($ukm_options as $id_ukm => $nama_ukm) : ?>
                      <option value="<?php echo $id_ukm; ?>" <?php echo ($id_ukm == $selected_ukm) ? 'selected' : ''; ?>><?php echo $nama_ukm; ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <button type="submit" class="btn btn-primary">Cari</button>
              </form>
            </div>
          </div>
          
           <?php if (empty($selected_ukm)) : ?>
              <p>Silakan pilih UKM dari dropdown di atas.</p>
            <?php else : ?>
                <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th>NIM</th>
                            <th>Nama Mahasiswa</th>
                            <th>UKM</th>
                            <th>Aksi</th>
                          </tr>
                        </thead>

                        <?php
                        foreach ($daftar as $d) { ?>
                          <tr>
                            <td><?php echo $d['nim'] ?></td>
                            <td><?php echo $d['nama_mhs'] ?></td>
                            <td><?php echo $d['nama_ukm'] ?></td>
                            <td>
                              <a href=<?php echo base_url("admin/daftar_hapus/") . $d['id_daftar']; ?> onclick="return confirm('Yakin menghapus Mahasiswa : <?php echo $d['nama_mhs']; ?> ?');" ;>Keluarkan</a>

                            </td>
                          </tr>
                        <?php
                        }
                        ?>
                      </table>
            <?php endif; ?>


        </div>
      </div>
    </section>
  </div>

<?php
}

//--------------------------------- TAMBAH ---------------------------------
else if ($page == 'daftar_tambah') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Isikan Data Dengan Benar</h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors(); ?>

          <form method="POST" action="<?php echo base_url('admin/daftar_tambah'); ?>" class="form-horizontal">

            <div class="card-body">

               <div class="form-group row">
                <label for="nim" class="col-sm-2 col-form-label">NIM</label>
                <div class="col-sm-10">
                  <select name="nim" class="form-control">
                    <option value="">Pilih NIM</option>
                    <?php foreach ($ddmahasiswa as $nim => $nama_mhs) : ?>
                      <option value="<?php echo $nim; ?>" <?php echo set_select('nim', $nim); ?>><?php echo $nim . ' - ' . $nama_mhs; ?></option>
                    <?php endforeach; ?>
                  </select>
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nim')); ?></span>
                </div>
              </div>

               <div class="form-group row">
                <label for="id_ukm" class="col-sm-2 col-form-label">UKM</label>
                <div class="col-sm-10">
                  <select name="id_ukm" class="form-control">
                    <!-- <option value="">Pilih UKM</option> -->
                    <?php foreach ($ddukm as $id => $nama_ukm) : ?>
                      <option value="<?php echo $id; ?>" <?php echo set_select('id_ukm', $id); ?>><?php echo $nama_ukm; ?></option>
                    <?php endforeach; ?>
                  </select>
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('id_ukm')); ?></span>
                </div>
              </div>


            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">Tambah Anggota</button>
              <!-- <button type="reset" class="btn btn-danger">Reset</button> -->
              <a href="<?php echo base_url('admin/daftar'); ?>" class="btn btn-secondary">Kembali</a>
            </div>
          </form>

        </div>
      </div>
    </section>
  </div>

<?php
}

//--------------------------------- EDIT ---------------------------------
else if ($page == 'daftar_edit') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Isikan Data Dengan Benar</h3>
        </div>
        <div class="card-body">

          <?php echo validation_errors(); ?>

          <form method="POST" action="<?php echo base_url('admin/ukm_edit/' . $d['id_ukm']); ?>" class="form-horizontal">

            <div class="card-body">

              <div class="form-group row">
                <label for="id_ukm" class="col-sm-2 col-form-label">ID</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="id_ukm" id="id_ukm" value="<?php echo set_value('id_ukm', $d['id_ukm']); ?>" placeholder="Masukkan ID" readonly>
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('id_ukm')); ?></span>
                </div>
              </div>

              <div class="form-group row">
                <label for="nama_ukm" class="col-sm-2 col-form-label">Nama</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="nama_ukm" id="nama_ukm" value="<?php echo set_value('nama_ukm', $d['nama_ukm']); ?>" placeholder="Masukkan Nama UKM" >
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('nama_ukm')); ?></span>
                </div>
              </div>
              <div class="form-group row">
                <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="deskripsi" id="deskripsi" value="<?php echo set_value('deskripsi', $d['deskripsi']); ?>" placeholder="Masukkan Deskripsi" >
                  <span class="badge badge-warning"><?php echo strip_tags(form_error('deskripsi')); ?></span>
                </div>
              </div>

            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-info">Simpan</button>
              <button type="reset" class="btn btn-danger">Reset</button>
              <a href="<?php echo base_url('admin/ukm'); ?>" class="btn btn-secondary">Kembali</a>
            </div>
          </form>

        </div>
      </div>
    </section>
  </div>

<?php
}

//==================================== kelas ====================================
else if ($page == 'kelas') {
?>
  <div class="content-wrapper" style="padding-left:10px">

    <h1><?php echo  $judul; ?></h1>
    <a href=<?php echo base_url("admin/kelas_tambah") ?>>Tambah kelas</a>
    <table border=1>
      <tr>
        <th>Id kelas</th>
        <th>Nama</th>
        <th>Aksi</th>
      </tr>
      <?php
      foreach ($kelas as $d) { ?>
        <tr>
          <td><?php echo $d['id_kelas'] ?></td>
          <td><?php echo $d['nama_kelas'] ?></td>
          <td>
            <a href=<?php echo base_url("admin/kelas_edit/") . $d['id_kelas']; ?>>Edit </a>
            <a href=<?php echo base_url("admin/kelas_hapus/") . $d['id_kelas']; ?> onclick="return confirm('Yakin menghapus kelas : <?php echo $d['nama_kelas']; ?> ?');" ;> Hapus</a>
          </td>
        </tr>
      <?php
      }
      ?>
    </table>
    <br><i>Halaman Kelas ini sengaja tanpa Style CSS agar tampak Core Coding nya</i>

  </div>
<?php
}
//--------------------------------- TAMBAH ---------------------------------
else if ($page == 'kelas_tambah') {
?>
  <div class="content-wrapper" style="padding-left:10px">

    <h1><?php echo  $judul; ?></h1>

    <form method="POST" action="<?php echo base_url('admin/kelas_tambah'); ?>">
      Nama kelas
      <input type="text" name="nama_kelas" value="<?php echo set_value('nama_kelas'); ?>" placeholder="Masukkan Nama kelas">
      <?php echo form_error('nama_kelas'); ?><br>
      <input type="submit" value="Simpan">
    </form>
    <br><i>Halaman Tambah Kelas ini sengaja tanpa Style CSS agar tampak Core Coding nya<i><br><br>

  </div>
<?php
}
//--------------------------------- EDIT ---------------------------------
else if ($page == 'kelas_edit') {
?>
  <div class="content-wrapper" style="padding-left:10px">

    <h1><?php echo  $judul; ?></h1>
    <form method="POST" action="<?php echo base_url('admin/kelas_edit/' . $d['id_kelas']); ?>">
      Nama kelas
      <input type="text" name="nama_kelas" value="<?php echo set_value('nama_kelas', $d['nama_kelas']); ?>">
      <?php echo form_error('nama_kelas'); ?><br>
      <input type="submit" value="Simpan">
    </form>
    Create By Agus SBN @2022
    <i>Halaman EDIT Kelas ini sengaja tanpa Style CSS agar tampak Core Coding nya</i><br>
  </div>

<?php
}

//================================ LIST DATA SANTRI PER KELAS ================================
else if ($page == 'list_santri_per_kelas') {
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo  $judul; ?></h1>
          </div>
        </div>
      </div>
    </section>

    <section class="content">
      <div class="card">
        <div class="card-body">
          <div class="form-group">
            <div class="row">
              <div class="col-sm-2">
                Pilih Kelas
              </div>
              <div class="col-sm-2">
                <?php echo form_dropdown('id_kelas', $ddkelas, set_value('id_kelas'), 'id="pd_kelas" class="form-control"'); ?>
              </div>
            </div>
            <div class="col-sm-8">
            </div>
          </div>
          <!-- <button id="pilih_kelas" class='btn btn-info btn-sm' style="margin-bottom: 5px">Tampilkan</button> -->
          <table id="datatable_01" class="table table-bordered">
            <thead>
              <tr>
                <th>Id Santri</th>
                <th>Nama</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <?php
            foreach ($santri as $d) { ?>
              <tr>
                <td><?php echo $d['id_santri'] ?></td>
                <td><?php echo $d['nama_santri'] ?></td>
                <td>
                  <a href=<?php echo base_url("admin/santri_detil/") . $d['id_santri']; ?>>
                    <i class="fas fa-search-plus"></i></a>
                </td>
              </tr>
            <?php
            }
            ?>
          </table>

        </div>
    </section>
  </div>

<?php
}


?>