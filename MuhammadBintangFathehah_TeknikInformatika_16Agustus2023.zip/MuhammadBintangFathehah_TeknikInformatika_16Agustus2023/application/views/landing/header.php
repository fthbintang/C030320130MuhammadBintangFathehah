<!DOCTYPE html>
<html lang="en">

<head>

  <title>Soft Landing Page by Tooplate</title>
  <!--

    Template 2106 Soft Landing

	http://www.tooplate.com/view/2106-soft-landing

    -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="team" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/landing/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/landing/css/owl.carousel.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/landing/css/owl.theme.default.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/landing/css/font-awesome.min.css">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/adminlte/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- css Buatan sendiri -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style_umum.css">
  <!-- MAIN CSS -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/landing/css/tooplate-style.css">

</head>

<body>